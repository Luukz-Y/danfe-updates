import fitz  # PyMuPDF
from PIL import Image, ImageChops
import customtkinter as ctk
from tkinter import filedialog, messagebox
import re
from collections import Counter, defaultdict
import os
import subprocess
import platform
import time
import threading

# Importar sistema de auto-update
try:
    from updater import check_and_update
    from version import get_version
    UPDATE_AVAILABLE = True
except ImportError:
    UPDATE_AVAILABLE = False

# =========================
# Verificação de dependências e configuração de DPI
# =========================


def verificar_dependencias():
    """Verifica se todas as dependências necessárias estão disponíveis"""
    try:
        import fitz
        import PIL
        import customtkinter
        return True
    except ImportError as e:
        print(f"Erro de dependência: {e}")
        return False


def configurar_escalonamento_dpi():
    """Configura o escalonamento para tamanhos consistentes"""
    try:
        # Desabilitar escalonamento automático do CustomTkinter
        # para ter controle total sobre os tamanhos
        ctk.set_widget_scaling(1.0)
        ctk.set_window_scaling(1.0)

        return 1.0

    except Exception as e:
        print(f"Erro ao configurar DPI: {e}")
        # Fallback: usar escalonamento padrão
        ctk.set_widget_scaling(1.0)
        ctk.set_window_scaling(1.0)
        return 1.0


def configurar_dpi_awareness():
    """Configura awareness de DPI para Windows"""
    try:
        if platform.system() == "Windows":
            import ctypes
            from ctypes import wintypes

            # Configurar DPI awareness para Windows
            try:
                # Windows 10/11 - Per Monitor DPI Awareness
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except:
                try:
                    # Windows 8.1 - System DPI Awareness
                    ctypes.windll.user32.SetProcessDPIAware()
                except:
                    pass
    except Exception:
        pass


def configurar_ambiente_consistente():
    """Configura o ambiente para tamanhos consistentes"""
    try:
        # Configurar variáveis de ambiente para DPI
        if platform.system() == "Windows":
            os.environ['QT_AUTO_SCREEN_SCALE_FACTOR'] = '0'
            os.environ['QT_SCALE_FACTOR'] = '1'
            os.environ['QT_SCREEN_SCALE_FACTORS'] = '1'

        # Configurar CustomTkinter para não usar escalonamento automático
        ctk.set_widget_scaling(1.0)
        ctk.set_window_scaling(1.0)

    except Exception:
        pass


# =========================
# Configurações visuais / constantes
# =========================
DESLOC_INDICE_X = 5  # lado
DESLOC_INDICE_Y = 2  # cima/baixo
TAMANHO_INDICE = 10  # tamanho 1/x 2/x
AUMENTO_TEXTO_FACTOR = 1.5  # Texto SKU
HIGHLIGHT_OFFSET = 12
HIGHLIGHT_MARGIN_LEFT = 50
HIGHLIGHT_MARGIN_RIGHT = 50

# Posição fixa para os índices [x/y] - baseada na estrutura da DANFE
INDICE_POSICAO_FIXA_X = 400  # Posição X fixa para todos os índices
INDICE_OFFSET_Y = 25         # Offset Y a partir da linha do SKU

# Regex que identifica a linha de SKU (linha logo abaixo de "ITEM")
SKU_PATTERN = re.compile(r"^([A-Z0-9\/\-_\.]+)\s*-\s*(.*)", re.IGNORECASE)

# Regex para detectar frações do tipo "1/3", "2/3"
FRACAO_PATTERN = re.compile(r"\b(\d{1,2})/(\d{1,2})\b")


# =========================
# Funções auxiliares
# =========================
def detectar_posicao_ideal_indice(pagina):
    """
    Detecta a posição X ideal para colocar os índices [x/y] baseado na estrutura da DANFE.
    Procura pela coluna 'VL. ITEM' que geralmente fica à direita do SKU.
    """
    try:
        data = pagina.get_text("dict")
        for bloco in data.get("blocks", []):
            if "lines" in bloco:
                for linha in bloco["lines"]:
                    texto = " ".join([s["text"]
                                     for s in linha["spans"]]).strip()
                    if "VL. ITEM" in texto.upper():
                        # Encontrou a linha com "VL. ITEM", pega a posição X do primeiro span
                        if linha["spans"]:
                            # 20px antes do "VL. ITEM"
                            return linha["spans"][0]["bbox"][0] - 20
    except Exception:
        pass

    # Fallback: retorna posição padrão
    return INDICE_POSICAO_FIXA_X


def abrir_arquivo_para_impressao(caminho_arquivo):
    """
    Abre o arquivo PDF automaticamente para impressão no sistema operacional atual.
    """
    try:
        # Verificar se o arquivo existe
        if not os.path.exists(caminho_arquivo):
            return False

        sistema = platform.system().lower()

        if sistema == "windows":
            # Windows: usar os.startfile que funciona bem
            try:
                os.startfile(caminho_arquivo)
                return True
            except Exception:
                # Fallback: tentar com subprocess
                try:
                    subprocess.run(["start", "", caminho_arquivo],
                                   shell=True, check=True)
                    return True
                except Exception:
                    return False
        elif sistema == "darwin":  # macOS
            try:
                subprocess.run(
                    ["open", "-a", "Preview", caminho_arquivo], check=True)
                return True
            except Exception:
                # Fallback: abrir com aplicativo padrão
                try:
                    subprocess.run(["open", caminho_arquivo], check=True)
                    return True
                except Exception:
                    return False
        else:  # Linux e outros
            try:
                subprocess.run(["xdg-open", caminho_arquivo], check=True)
                return True
            except Exception:
                # Fallback: tentar outros comandos comuns
                for cmd in ["evince", "okular", "firefox", "chrome"]:
                    try:
                        subprocess.run([cmd, caminho_arquivo], check=True)
                        return True
                    except Exception:
                        continue
                return False

    except Exception as e:
        print(f"Erro ao abrir arquivo: {e}")
        return False


def detectar_bbox(pagina):
    """Detecta área útil da página, retornando fitz.Rect do conteúdo."""
    pix = pagina.get_pixmap(dpi=150)
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    bg = Image.new("RGB", img.size, (255, 255, 255))
    diff = ImageChops.difference(img, bg)
    bbox = diff.getbbox()
    if not bbox:
        return pagina.rect
    x0, y0, x1, y1 = bbox
    fator_x = pagina.rect.width / pix.width if pix.width != 0 else 1
    fator_y = pagina.rect.height / pix.height if pix.height != 0 else 1
    return fitz.Rect(x0 * fator_x, y0 * fator_y, x1 * fator_x, y1 * fator_y)


def destacar_textos_amarelos(pagina):
    """
    Aumenta (destaca) apenas a parte do SKU (antes do traço) da linha logo abaixo de 'ITEM'
    e/ou o número abaixo de 'QTD. TOTAL DE ITENS'.
    O nome do produto (após o traço) mantém o tamanho original.
    """
    try:
        data = pagina.get_text("dict")
        linhas = []
        for bloco in data.get("blocks", []):
            if "lines" in bloco:
                for linha in bloco["lines"]:
                    texto = " ".join([s["text"]
                                     for s in linha["spans"]]).strip()
                    spans = linha["spans"]
                    if texto:
                        linhas.append({"texto": texto, "spans": spans})

        spans_para_aumentar = []
        spans_com_info = []  # Lista para armazenar spans com informação sobre múltiplos itens

        for idx, linha in enumerate(linhas):
            texto = linha["texto"]
            # Se houver 'ITEM' na linha (por exemplo: "ITEM | VL. ITEM"), pega TODAS as próximas que contenham SKU
            if "ITEM" in texto.upper():
                # Primeiro, conta quantos itens há nesta nota
                itens_encontrados = []
                for j in range(idx + 1, len(linhas)):
                    prox_texto = linhas[j]["texto"]
                    # Para quando encontra uma linha que não é um SKU (ex: "QTD. TOTAL DE ITENS")
                    if "QTD. TOTAL DE ITENS" in prox_texto.upper() or "CONSUMIDOR" in prox_texto.upper():
                        break
                    # Se a linha contém um SKU (formato "CÓDIGO - descrição")
                    if " - " in prox_texto and len(prox_texto) > 3:
                        itens_encontrados.append(linhas[j]["spans"])

                # Verifica se há múltiplos itens
                tem_multiplos = len(itens_encontrados) > 1

                # Adiciona todos os itens encontrados com informação sobre múltiplos itens
                for spans_item in itens_encontrados:
                    spans_para_aumentar.extend(spans_item)
                    # Armazena informação sobre múltiplos itens para cada span
                    for span in spans_item:
                        spans_com_info.append({
                            "span": span,
                            "tem_multiplos_itens": tem_multiplos
                        })
            # QTD. TOTAL DE ITENS -> aumenta o número na próxima linha (se for número)
            elif "QTD. TOTAL DE ITENS" in texto:
                for j in range(idx + 1, min(idx + 4, len(linhas))):
                    prox_texto = linhas[j]["texto"]
                    if prox_texto.strip().isdigit():
                        spans_para_aumentar.extend(linhas[j]["spans"])
                        # Para QTD, não há múltiplos itens
                        for span in linhas[j]["spans"]:
                            spans_com_info.append({
                                "span": span,
                                "tem_multiplos_itens": False
                            })
                        break

        # aplicar aumento nos spans coletados, separando SKU do nome do produto
        for span_info in spans_com_info:
            span = span_info["span"]
            tem_multiplos_itens = span_info["tem_multiplos_itens"]

            texto_span = span.get("text", "").strip()
            if not texto_span:
                continue
            try:
                tamanho_original = span.get("size", 10)
                x0, y0, x1, y1 = span["bbox"]
                pad = 1
                rect = fitz.Rect(x0 - pad, y0 - pad, x1 + pad, y1 + pad)
                pagina.draw_rect(rect, color=(1, 1, 1), fill=(1, 1, 1))

                # Verificar se há múltiplos itens para ajustar o fator de aumento
                if tem_multiplos_itens:
                    # Para múltiplos itens, usar um fator menor para evitar sobreposição
                    fator_aumento = 1.2  # Menor que o padrão 1.5
                else:
                    # Para item único, usar o fator padrão
                    fator_aumento = AUMENTO_TEXTO_FACTOR

                # Verificar se o texto contém um traço para separar SKU do nome
                if " - " in texto_span:
                    # Separar SKU (antes do traço) do nome do produto (após o traço)
                    partes = texto_span.split(" - ", 1)
                    sku = partes[0].strip()
                    nome_produto = partes[1].strip() if len(partes) > 1 else ""

                    # Calcular posições para cada parte
                    pos_x_atual = x0

                    # Desenhar SKU com fonte maior (ajustada para múltiplos itens)
                    if sku:
                        novo_tamanho_sku = max(
                            8, int(tamanho_original * fator_aumento))
                        pos_y = y0 + novo_tamanho_sku * 0.8
                        pagina.insert_text((pos_x_atual, pos_y), sku,
                                           fontsize=novo_tamanho_sku, fontname="helv", fill=(0, 0, 0))

                        # Calcular largura do SKU para posicionar o traço
                        # Usar uma estimativa baseada no tamanho da fonte
                        largura_sku_estimada = len(
                            sku) * novo_tamanho_sku * 0.6
                        pos_x_atual += largura_sku_estimada

                    # Desenhar traço com fonte original
                    if nome_produto:  # Só desenha o traço se houver nome do produto
                        traco = " - "
                        pos_y_traco = y0 + tamanho_original * 0.8
                        pagina.insert_text((pos_x_atual, pos_y_traco), traco,
                                           fontsize=tamanho_original, fontname="helv", fill=(0, 0, 0))

                        # Calcular largura do traço
                        largura_traco_estimada = len(
                            traco) * tamanho_original * 0.6
                        pos_x_atual += largura_traco_estimada

                        # Desenhar nome do produto com fonte original (menor)
                        pos_y_nome = y0 + tamanho_original * 0.8
                        pagina.insert_text((pos_x_atual, pos_y_nome), nome_produto,
                                           fontsize=tamanho_original, fontname="helv", fill=(0, 0, 0))

                        # Detectar e destacar quantidade (ex: "2,00 UN") apenas se for maior que 2
                        import re
                        # Padrão para detectar quantidade: número com vírgula + " UN"
                        padrao_quantidade = r'(\d+,\d+)\s+UN'
                        match_quantidade = re.search(
                            padrao_quantidade, nome_produto)

                        if match_quantidade:
                            quantidade_texto = match_quantidade.group(
                                0)  # Ex: "2,00 UN"
                            quantidade_numero = match_quantidade.group(
                                1)  # Ex: "2,00"

                            # Converter quantidade para float para comparar
                            try:
                                quantidade_float = float(
                                    quantidade_numero.replace(',', '.'))

                                # Só destacar se a quantidade for maior que 1
                                if quantidade_float > 1:
                                    # Encontrar posição da quantidade no texto
                                    pos_quantidade = nome_produto.find(
                                        quantidade_texto)
                                    if pos_quantidade != -1:
                                        # Calcular posição X da quantidade com melhor precisão
                                        # Usar uma estimativa mais precisa baseada no tamanho da fonte
                                        largura_antes_quantidade = len(
                                            nome_produto[:pos_quantidade]) * tamanho_original * 0.5
                                        pos_x_quantidade = pos_x_atual + largura_antes_quantidade

                                        # Calcular largura apenas do número da quantidade (sem " UN")
                                        # Extrair apenas o número (ex: "2,00" de "2,00 UN")
                                        numero_quantidade = quantidade_numero  # Ex: "2,00"
                                        largura_numero = len(
                                            numero_quantidade) * tamanho_original * 5

                                        # Desenhar highlight (linha) abaixo apenas do número da quantidade
                                        y_highlight = y1 + 3  # 3 pixels abaixo da linha do texto
                                        pagina.draw_line(
                                            (pos_x_quantidade, y_highlight),
                                            (pos_x_quantidade +
                                             largura_numero, y_highlight),
                                            color=(0, 0, 0),
                                            width=3.0
                                        )
                            except ValueError:
                                # Se não conseguir converter, não faz nada
                                pass
                else:
                    # Se não há traço, aplicar aumento normal em todo o texto
                    novo_tamanho = max(
                        8, int(tamanho_original * fator_aumento))
                    pos_y = y0 + novo_tamanho * 0.8
                    pagina.insert_text((x0, pos_y), texto_span,
                                       fontsize=novo_tamanho, fontname="helv", fill=(0, 0, 0))
            except Exception:
                continue
    except Exception as e:
        print("Erro em destacar_textos_amarelos:", e)


# =========================
# Varredura preliminar: coletar SKUs (relaxed detection)
# =========================
def escanear_documento_para_skus(doc):
    """
    Varre todo o documento e retorna:
      occurrences_per_page: dict {page_index: [ {sku, bbox, qtd, texto}, ... ] }
      totals: Counter({sku: total_occurrences})
    Observação: usamos detecção relaxada de 'ITEM' (procura 'ITEM' na linha).
    """
    occurrences_per_page = {}
    totals = Counter()

    for pidx, page in enumerate(doc):
        data = page.get_text("dict")
        linhas = []
        for bloco in data.get("blocks", []):
            if "lines" in bloco:
                for linha in bloco["lines"]:
                    texto = " ".join([s["text"]
                                     for s in linha["spans"]]).strip()
                    spans = linha["spans"]
                    if texto:
                        linhas.append((texto, spans))

        occs = []
        for i, (texto, spans) in enumerate(linhas):
            # Relaxed: procura por 'ITEM' dentro da linha (ex.: "ITEM | VL. ITEM")
            if "ITEM" in texto.upper() and i + 1 < len(linhas):
                prox_texto, prox_spans = linhas[i + 1]
                prox_text = prox_texto.strip()
                # Remove eventuais colunas após '|' (ex.: preço) para analisar o texto do SKU
                if "|" in prox_text:
                    prox_text = prox_text.split("|")[0].strip()
                m = SKU_PATTERN.match(prox_text)
                if m:
                    sku = m.group(1).upper()
                    # procura 'Quantidade:' nas próximas linhas (se houver)
                    quantidade = 1
                    for j in range(i + 1, min(i + 6, len(linhas))):
                        t2, _ = linhas[j]
                        if "Quantidade:" in t2:
                            try:
                                quantidade = int(t2.split("Quantidade:")[
                                                 1].strip().split()[0])
                            except Exception:
                                quantidade = 1
                            break
                    x0s = [s["bbox"][0] for s in prox_spans]
                    y0s = [s["bbox"][1] for s in prox_spans]
                    x1s = [s["bbox"][2] for s in prox_spans]
                    y1s = [s["bbox"][3] for s in prox_spans]
                    line_bbox = (min(x0s), min(y0s), max(x1s), max(y1s))
                    occs.append({"sku": sku, "bbox": line_bbox,
                                "qtd": quantidade, "text": prox_text})
                    totals[sku] += 1

        occurrences_per_page[pidx] = occs

    return occurrences_per_page, totals


# =========================
# Nova função: ordenar páginas por grupos de fração (1/3, 2/3, ...)
# =========================
def ordenar_paginas_por_grupo(doc, occurrences_per_page):
    """
    Detecta páginas que contenham frações do tipo X/Y e agrupa páginas que tenham:
      - mesmo SKU principal (primeiro SKU detectado na página, se houver)
      - mesmo total Y (da fração)
    Retorna uma lista com índices de páginas na ordem desejada:
      - primeiro todos os grupos (cada grupo ordenado por X ascendente)
      - depois as páginas restantes na ordem original
    """
    page_meta = {}
    num_pages = len(doc)
    for pidx in range(num_pages):
        page = doc[pidx]
        text = page.get_text("text") or ""
        # procurar pela primeira fração na página
        m = FRACAO_PATTERN.search(text)
        skus = [occ["sku"] for occ in occurrences_per_page.get(pidx, [])]
        if m:
            num = int(m.group(1))
            total = int(m.group(2))
            sku_chave = skus[0] if skus else f"NOPSKU_{pidx}"
            group_key = (sku_chave, total)
            page_meta[pidx] = {"group": group_key, "num": num}
        else:
            page_meta[pidx] = {"group": None, "num": None}

    # construir os grupos
    groups = defaultdict(list)  # key -> list of (num, pidx)
    for pidx, meta in page_meta.items():
        if meta["group"] is not None:
            groups[meta["group"]].append((meta["num"], pidx))

    # ordenar grupos pela primeira ocorrência no documento (para preservar ordem geral)
    groups_ordered = sorted(
        groups.items(), key=lambda kv: min([p for _, p in kv[1]]))

    ordered = []
    for key, lst in groups_ordered:
        # ordenar páginas do grupo por numero X (1..Y)
        lst_sorted = sorted(lst, key=lambda x: x[0])
        ordered.extend([pidx for _, pidx in lst_sorted])

    # adicionar páginas que não fazem parte de grupos, mantendo ordem original
    for pidx in range(num_pages):
        if pidx not in ordered:
            ordered.append(pidx)

    return ordered


# =========================
# Função principal de compactação (mantida + integrada com reordenação)
# =========================
def compactar_pdf_com_recorte(entrada, saida, etiquetas_por_pagina=3, destacar_textos=False):
    """
    Compacta 3 DANFEs por folha, recorta margens e
    adiciona destaques (opcional) e índices [n/x] sob ITEM (global).
    Implementação agora reordena páginas para agrupar frações 1/3 2/3 3/3.
    """
    doc = fitz.open(entrada)
    novo = fitz.open()

    largura, altura = fitz.paper_size("a4")
    slot_h = altura / etiquetas_por_pagina
    contador = 0

    # 1) varredura preliminar: coletar ocorrências e totais (antes de qualquer modificação)
    occurrences_per_page, totals = escanear_documento_para_skus(doc)
    usados_global = defaultdict(int)

    # 1.5) determinar ordem de processamento das páginas (agrupando frações)
    ordem_paginas = ordenar_paginas_por_grupo(doc, occurrences_per_page)

    # 2) processar cada página (na ordem determinada): criar página temporária com edições (indices+highlight)
    for orig_index in ordem_paginas:
        pagina = doc[orig_index]
        if contador % etiquetas_por_pagina == 0:
            pagina_nova = novo.new_page(width=largura, height=altura)

        linha = contador % etiquetas_por_pagina
        destino = fitz.Rect(5, linha * slot_h, largura -
                            5, (linha + 1) * slot_h)

        # Detecta área útil do original (clip) antes da cópia
        clip = detectar_bbox(pagina)

        # Criar cópia temporária (mesmas dimensões) para editar
        tmp = fitz.open()
        tmp_page = tmp.new_page(width=pagina.rect.width,
                                height=pagina.rect.height)
        # copia conteúdo da página original
        tmp_page.show_pdf_page(tmp_page.rect, doc, orig_index)

        # 2a) aplicar destaque/ampliação no tmp_page (se solicitado)
        if destacar_textos:
            try:
                destacar_textos_amarelos(tmp_page)
            except Exception:
                pass  # não interrompe se highlight falhar

        # 2b) inserir índices [n/X] e highlights (na tmp_page)
        # Detectar posição ideal para os índices baseada na estrutura da DANFE
        pos_x_ideal = detectar_posicao_ideal_indice(tmp_page)

        occs = occurrences_per_page.get(orig_index, [])
        for occ in occs:
            sku = occ["sku"]
            x0, y0, x1, y1 = occ["bbox"]
            usados_global[sku] += 1
            idx_atual = usados_global[sku]
            idx_total = totals.get(sku, 1)
            texto_indice = f"[{idx_atual}/{idx_total}]"

            # Usar posição detectada automaticamente ou fallback para posição fixa
            pos_x_fixa = pos_x_ideal
            pos_y_relativa = y0 + INDICE_OFFSET_Y

            try:
                tmp_page.insert_text((pos_x_fixa, pos_y_relativa),
                                     texto_indice,
                                     fontsize=TAMANHO_INDICE,
                                     fontname="helv",
                                     fill=(0, 0, 0))
            except Exception:
                # Fallback: tentar posição ligeiramente diferente se a posição fixa falhar
                try:
                    tmp_page.insert_text((pos_x_fixa, y0 + 4),
                                         texto_indice,
                                         fontsize=TAMANHO_INDICE,
                                         fontname="helv",
                                         fill=(0, 0, 0))
                except Exception:
                    # Último recurso: usar posição original
                    try:
                        tmp_page.insert_text((x1 + DESLOC_INDICE_X, y0 + DESLOC_INDICE_Y),
                                             texto_indice,
                                             fontsize=TAMANHO_INDICE,
                                             fontname="helv",
                                             fill=(0, 0, 0))
                    except Exception:
                        pass

            # Se qtd > 1, desenhar highlight grande (linha) abaixo do SKU na tmp_page
            if occ.get("qtd", 1) > 1:
                try:
                    largura_pagina = tmp_page.rect.width
                    y_linha = y1 + HIGHLIGHT_OFFSET
                    x_inicio = HIGHLIGHT_MARGIN_LEFT
                    x_fim = largura_pagina - HIGHLIGHT_MARGIN_RIGHT
                    tmp_page.draw_line(
                        (x_inicio, y_linha), (x_fim, y_linha), color=(0, 0, 0), width=1.5)
                except Exception:
                    pass

        # 3) agora copiamos a tmp_page (já editada) para a página destino do novo documento,
        #    usando o mesmo clip (recorte) que queremos aplicar.
        pagina_nova.show_pdf_page(destino, tmp, 0, clip=clip)
        tmp.close()
        contador += 1

    novo.save(saida)
    novo.close()
    doc.close()
    return True


# =========================
# Interface (CustomTkinter)
# =========================
class PDFApp(ctk.CTk):
    def __init__(self):
        # Configurar ambiente consistente ANTES de criar a janela
        configurar_ambiente_consistente()
        configurar_dpi_awareness()

        super().__init__()
        self.title("DANFE Compactador")

        # Configurar escalonamento DPI antes de definir geometria
        self.fator_escala = configurar_escalonamento_dpi()

        # Definir tamanho fixo para consistência entre computadores
        self.geometry("450x430")
        self.resizable(False, False)

        # Forçar tamanho mínimo e máximo para garantir consistência
        self.minsize(450, 450)
        self.maxsize(450, 450)

        # Tentar carregar ícone, mas não falhar se não existir
        try:
            if os.path.exists('lc.ico'):
                self.iconbitmap('lc.ico')
        except Exception:
            # Se não conseguir carregar o ícone, continua sem ele
            pass

        # Configuração visual profissional com tratamento de erro
        try:
            ctk.set_appearance_mode("light")
            ctk.set_default_color_theme("blue")
        except Exception:
            # Se houver erro na configuração visual, continua com padrões
            pass

        # Centralizar janela
        self.center_window()

        # Forçar tamanho após centralização para garantir consistência
        self.after(100, self.forcar_tamanho_consistente)

        self.arquivo_entrada = None
        self.destacar_textos = ctk.BooleanVar(value=True)

        # Configurar grid responsivo
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header com título e ícone
        self.create_header()

        # Main content area
        self.create_main_content()

        # Footer com informações
        self.create_footer()
        
        # Verificar atualizações em background (após 2 segundos)
        if UPDATE_AVAILABLE:
            self.after(2000, self._check_updates_background)

    def center_window(self):
        """Centraliza a janela na tela de forma robusta considerando DPI"""
        try:
            # Força a atualização da janela para obter dimensões corretas
            self.update_idletasks()

            # Obtém dimensões da janela
            width = self.winfo_width()
            height = self.winfo_height()

            # Se as dimensões ainda não estão disponíveis, usa valores padrão
            if width <= 1 or height <= 1:
                width, height = 450, 450

            # Obtém dimensões da tela
            screen_width = self.winfo_screenwidth()
            screen_height = self.winfo_screenheight()

            # Calcula posição central
            x = (screen_width - width) // 2
            y = (screen_height - height) // 2

            # Garante que a janela não saia da tela
            x = max(0, min(x, screen_width - width))
            y = max(0, min(y, screen_height - height))

            # Aplica a geometria
            self.geometry(f"{width}x{height}+{x}+{y}")

        except Exception:
            # Se houver qualquer erro, usa geometria padrão
            self.geometry("450x450")

    def forcar_tamanho_consistente(self):
        """Força o tamanho da janela para ser consistente"""
        try:
            # Força o tamanho exato
            self.geometry("450x450")
            self.minsize(450, 450)
            self.maxsize(450, 450)

            # Re-centraliza após forçar tamanho
            self.center_window()
        except Exception:
            pass

    def create_header(self):
        """Cria o cabeçalho da aplicação"""
        header_frame = ctk.CTkFrame(self, height=60, corner_radius=0)
        header_frame.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        header_frame.grid_columnconfigure(0, weight=1)

        # Título principal
        title_label = ctk.CTkLabel(
            header_frame,
            text="DANFE Simplificado ",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color=("#1f538d", "#14375e")
        )
        title_label.grid(row=0, column=0, pady=(10, 2))

        # Subtítulo
        subtitle_label = ctk.CTkLabel(
            header_frame,
            text="3 por folha com índices automáticos",
            font=ctk.CTkFont(size=12),
            text_color=("#666666", "#cccccc")
        )
        subtitle_label.grid(row=1, column=0, pady=(0, 8))

    def create_main_content(self):
        """Cria a área principal de conteúdo"""
        main_frame = ctk.CTkFrame(self, corner_radius=12)
        main_frame.grid(row=1, column=0, sticky="nsew", padx=15, pady=8)
        main_frame.grid_columnconfigure(0, weight=1)

        # Seção de seleção de arquivo
        file_section = ctk.CTkFrame(main_frame, fg_color="transparent")
        file_section.grid(row=0, column=0, sticky="ew", padx=15, pady=12)
        file_section.grid_columnconfigure(0, weight=1)

        # Ícone de arquivo (usando emoji como placeholder)
        file_icon = ctk.CTkLabel(
            file_section,
            text="📄",
            font=ctk.CTkFont(size=32)
        )
        file_icon.grid(row=0, column=0, pady=(0, 5))

        # Título da seção
        section_title = ctk.CTkLabel(
            file_section,
            text="Selecionar Arquivo PDF",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        section_title.grid(row=1, column=0, pady=(0, 8))

        # Botão de seleção
        self.select_btn = ctk.CTkButton(
            file_section,
            text="📁 Escolher PDF de DANFE",
            command=self.selecionar_pdf,
            height=35,
            font=ctk.CTkFont(size=14, weight="bold"),
            corner_radius=20
        )
        self.select_btn.grid(row=2, column=0, pady=(0, 8))

        # Label do arquivo selecionado
        self.lbl_pdf = ctk.CTkLabel(
            file_section,
            text="Nenhum arquivo selecionado",
            font=ctk.CTkFont(size=11),
            text_color=("#666666", "#cccccc"),
            wraplength=500
        )
        self.lbl_pdf.grid(row=3, column=0, pady=(0, 10))

        # Separador
        separator = ctk.CTkFrame(
            file_section, height=1, fg_color=("#e0e0e0", "#404040"))
        separator.grid(row=4, column=0, sticky="ew", pady=5)

        # Seção de opções
        options_section = ctk.CTkFrame(main_frame, fg_color="transparent")
        options_section.grid(row=1, column=0, sticky="ew", padx=15, pady=5)
        options_section.grid_columnconfigure(0, weight=1)

        # Checkbox para destacar
        self.checkbox_destacar = ctk.CTkCheckBox(
            options_section,
            text="✨ Destacar códigos SKU e quantidades",
            variable=self.destacar_textos,
            font=ctk.CTkFont(size=12),
            corner_radius=15
        )
        self.checkbox_destacar.grid(row=0, column=0, pady=5)

        # Botão principal de processamento
        process_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        process_frame.grid(row=2, column=0, sticky="ew", padx=15, pady=10)
        process_frame.grid_columnconfigure(0, weight=1)

        self.process_btn = ctk.CTkButton(
            process_frame,
            text="🚀 Compactar e Imprimir",
            command=self.processar,
            height=40,
            font=ctk.CTkFont(size=16, weight="bold"),
            corner_radius=25,
            fg_color=("#1f538d", "#14375e"),
            hover_color=("#2a6bb3", "#1a4a7a")
        )
        self.process_btn.grid(row=0, column=0, pady=5)
        
        # Botão de verificar atualizações (se disponível)
        if UPDATE_AVAILABLE:
            self.update_btn = ctk.CTkButton(
                process_frame,
                text="🔄 Verificar Atualizações",
                command=self._check_updates_manual,
                height=30,
                font=ctk.CTkFont(size=12),
                corner_radius=15,
                fg_color=("#666666", "#444444"),
                hover_color=("#777777", "#555555")
            )
            self.update_btn.grid(row=1, column=0, pady=(5, 0))

    def create_footer(self):
        """Cria o rodapé com informações"""
        footer_frame = ctk.CTkFrame(
            self, height=40, corner_radius=0, fg_color="transparent")
        footer_frame.grid(row=2, column=0, sticky="ew", padx=0, pady=0)
        footer_frame.grid_columnconfigure(0, weight=1)

        # Informações do sistema
        version_text = f"v{get_version()}" if UPDATE_AVAILABLE else "v1.0.0"
        system_info = ctk.CTkLabel(
            footer_frame,
            text=f"Desenvolvido por Lucas Alexandre • {version_text}",
            font=ctk.CTkFont(size=9),
            text_color=("#999999", "#666666")
        )
        system_info.grid(row=1, column=0, pady=(0, 5))

    def selecionar_pdf(self):
        """Seleciona arquivo PDF com feedback visual melhorado"""
        caminho = filedialog.askopenfilename(
            title="Selecionar PDF de DANFE",
            filetypes=[("Arquivos PDF", "*.pdf"), ("Todos os arquivos", "*.*")]
        )
        if caminho:
            self.arquivo_entrada = caminho
            # Mostrar apenas o nome do arquivo, não o caminho completo
            nome_arquivo = os.path.basename(caminho)
            self.lbl_pdf.configure(
                text=f"✅ {nome_arquivo}",
                text_color=("#2d5a27", "#90ee90")
            )
            # Habilitar botão de processamento
            self.process_btn.configure(state="normal")

    def processar(self):
        """Processa o PDF com feedback visual"""
        if not self.arquivo_entrada:
            messagebox.showwarning(
                "Atenção", "Selecione um arquivo PDF primeiro.")
            return

        # Desabilitar botão durante processamento
        self.process_btn.configure(state="disabled", text="⏳ Processando...")
        self.update()

        # Gerar nome do arquivo de saída automaticamente no mesmo diretório
        diretorio_origem = os.path.dirname(self.arquivo_entrada)
        nome_origem = os.path.splitext(
            os.path.basename(self.arquivo_entrada))[0]
        saida = os.path.join(
            diretorio_origem, f"{nome_origem}-Atualizado.pdf")

        try:
            # Mostrar progresso visual
            self.lbl_pdf.configure(
                text="🔄 Compactando PDF... Aguarde...",
                text_color=("#1f538d", "#87ceeb")
            )
            self.update()

            compactar_pdf_com_recorte(
                self.arquivo_entrada,
                saida,
                etiquetas_por_pagina=3,
                destacar_textos=self.destacar_textos.get()
            )

            # Verificar se o arquivo foi criado corretamente
            if os.path.exists(saida) and os.path.getsize(saida) > 0:
                # Pequeno delay para garantir que o arquivo foi completamente salvo
                time.sleep(0.5)

                # Atualizar interface com sucesso
                nome_saida = os.path.basename(saida)
                self.lbl_pdf.configure(
                    text=f"✅ {nome_saida}",
                    text_color=("#2d5a27", "#90ee90")
                )

                # Tentar abrir automaticamente para impressão
                if abrir_arquivo_para_impressao(saida):
                    messagebox.showinfo(
                        "🎉 Sucesso!",
                        f"PDF compactado e salvo com sucesso!\n\n"
                        f"📁 Arquivo: {nome_saida}\n"
                        f"📂 Local: {diretorio_origem}\n\n"
                        f"🖨️ Arquivo aberto automaticamente para impressão!"
                    )
                else:
                    messagebox.showinfo(
                        "✅ Sucesso!",
                        f"PDF compactado e salvo com sucesso!\n\n"
                        f"📁 Arquivo: {nome_saida}\n"
                        f"📂 Local: {diretorio_origem}\n\n"
                        f"Abra o arquivo manualmente para imprimir."
                    )
            else:
                self.lbl_pdf.configure(
                    text="❌ Erro ao criar arquivo",
                    text_color=("#d32f2f", "#ffcdd2")
                )
                messagebox.showerror("Erro",
                                     f"Arquivo não foi criado corretamente:\n{saida}")

        except Exception as e:
            self.lbl_pdf.configure(
                text="❌ Erro no processamento",
                text_color=("#d32f2f", "#ffcdd2")
            )
            messagebox.showerror("Erro", f"Ocorreu um problema:\n{e}")
        finally:
            # Reabilitar botão
            self.process_btn.configure(
                state="normal", text="🚀 Compactar e Imprimir")
    
    def _check_updates_background(self):
        """Verifica atualizações em background"""
        def check_thread():
            try:
                check_and_update(parent=self, silent=True)
            except Exception:
                # Falha silenciosa - não interrompe o uso do app
                pass
        
        # Executar em thread separada para não bloquear a UI
        threading.Thread(target=check_thread, daemon=True).start()
    
    def _check_updates_manual(self):
        """Verifica atualizações manualmente"""
        if not UPDATE_AVAILABLE:
            messagebox.showwarning("Aviso", "Sistema de atualização não disponível.")
            return
        
        # Desabilitar botão durante verificação
        self.update_btn.configure(state="disabled", text="🔍 Verificando...")
        
        def check_thread():
            try:
                has_update = check_and_update(parent=self, silent=False)
                if not has_update:
                    # Se não há atualização, mostrar mensagem
                    self.after(0, lambda: messagebox.showinfo(
                        "Atualizações", 
                        "Você está usando a versão mais recente!"
                    ))
            except Exception as e:
                self.after(0, lambda: messagebox.showerror(
                    "Erro", 
                    f"Erro ao verificar atualizações:\n{e}"
                ))
            finally:
                # Reabilitar botão
                self.after(0, lambda: self.update_btn.configure(
                    state="normal", text="🔄 Verificar Atualizações"
                ))
        
        threading.Thread(target=check_thread, daemon=True).start()


if __name__ == "__main__":
    # Verificar dependências antes de iniciar
    if not verificar_dependencias():
        print(
            "Erro: Dependências não encontradas. Execute 'pip install -r requirements.txt'")
        input("Pressione Enter para sair...")
        exit(1)

    # Configurar ambiente consistente ANTES de criar a aplicação
    configurar_ambiente_consistente()

    try:
        app = PDFApp()
        app.mainloop()
    except Exception as e:
        print(f"Erro ao iniciar aplicação: {e}")
        input("Pressione Enter para sair...")
        exit(1)
