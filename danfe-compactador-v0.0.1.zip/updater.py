#!/usr/bin/env python3
"""
Sistema de Auto-Update - DANFE Compactador
"""

import os
import sys
import json
import shutil
import tempfile
import threading
import time
from datetime import datetime
import urllib.request
import urllib.error
from pathlib import Path

try:
    import customtkinter as ctk
    from tkinter import messagebox
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

from version import CURRENT_VERSION, UPDATE_BASE_URL, compare_versions

class UpdateChecker:
    def __init__(self, base_url=None):
        self.base_url = base_url or UPDATE_BASE_URL
        self.current_version = CURRENT_VERSION
        self.latest_version = None
        self.update_info = None
        self.download_progress = 0
        
    def check_for_updates(self, silent=False):
        """
        Verifica se há atualizações disponíveis
        Retorna: (has_update, version_info, error_message)
        """
        try:
            # URL para verificar versão mais recente
            version_url = f"{self.base_url}/version.json"
            
            if not silent:
                print(f"🔍 Verificando atualizações em: {version_url}")
            
            # Fazer requisição HTTP
            with urllib.request.urlopen(version_url, timeout=10) as response:
                data = json.loads(response.read().decode())
            
            self.latest_version = data.get('version', '')
            self.update_info = data
            
            # Comparar versões
            if compare_versions(self.current_version, self.latest_version) < 0:
                if not silent:
                    print(f"✅ Nova versão disponível: {self.latest_version}")
                return True, data, None
            else:
                if not silent:
                    print(f"✅ Você está usando a versão mais recente: {self.current_version}")
                return False, data, None
                
        except urllib.error.URLError as e:
            error_msg = f"Erro de conexão: {e}"
            if not silent:
                print(f"❌ {error_msg}")
            return False, None, error_msg
        except json.JSONDecodeError as e:
            error_msg = f"Erro ao decodificar resposta: {e}"
            if not silent:
                print(f"❌ {error_msg}")
            return False, None, error_msg
        except Exception as e:
            error_msg = f"Erro inesperado: {e}"
            if not silent:
                print(f"❌ {error_msg}")
            return False, None, error_msg
    
    def download_update(self, progress_callback=None):
        """
        Baixa a atualização mais recente
        progress_callback: função chamada com (bytes_downloaded, total_bytes)
        """
        try:
            if not self.update_info:
                raise Exception("Informações de atualização não disponíveis")
            
            download_url = self.update_info.get('download_url')
            if not download_url:
                raise Exception("URL de download não encontrada")
            
            # Criar diretório temporário
            temp_dir = tempfile.mkdtemp(prefix="danfe_update_")
            download_path = os.path.join(temp_dir, "update.zip")
            
            print(f"📥 Baixando atualização de: {download_url}")
            
            # Baixar arquivo
            def progress_hook(block_num, block_size, total_size):
                if total_size > 0:
                    downloaded = block_num * block_size
                    progress = (downloaded / total_size) * 100
                    self.download_progress = progress
                    if progress_callback:
                        progress_callback(downloaded, total_size)
                    print(f"\r📥 Progresso: {progress:.1f}%", end="", flush=True)
            
            urllib.request.urlretrieve(download_url, download_path, progress_hook)
            print()  # Nova linha após progresso
            
            return download_path
            
        except Exception as e:
            print(f"❌ Erro ao baixar atualização: {e}")
            return None
    
    def install_update(self, update_path):
        """
        Instala a atualização baixada
        """
        try:
            print("🔧 Instalando atualização...")
            
            # Extrair arquivo ZIP
            import zipfile
            extract_dir = tempfile.mkdtemp(prefix="danfe_extract_")
            
            with zipfile.ZipFile(update_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # Obter diretório atual do aplicativo
            app_dir = os.path.dirname(os.path.abspath(__file__))
            
            # Lista de arquivos para atualizar (exceto arquivos de configuração)
            files_to_update = [
                'index.py',
                'version.py',
                'updater.py',
                'gerar_licencas.py'
            ]
            
            # Fazer backup dos arquivos atuais
            backup_dir = os.path.join(app_dir, 'backup')
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            version_backup_dir = os.path.join(backup_dir, f"v{self.current_version}_{timestamp}")
            os.makedirs(version_backup_dir, exist_ok=True)
            
            # Backup dos arquivos atuais
            for file_name in files_to_update:
                current_file = os.path.join(app_dir, file_name)
                if os.path.exists(current_file):
                    backup_file = os.path.join(version_backup_dir, file_name)
                    shutil.copy2(current_file, backup_file)
            
            # Atualizar arquivos
            for file_name in files_to_update:
                new_file = os.path.join(extract_dir, file_name)
                if os.path.exists(new_file):
                    current_file = os.path.join(app_dir, file_name)
                    shutil.copy2(new_file, current_file)
                    print(f"✅ Atualizado: {file_name}")
            
            # Limpar arquivos temporários
            shutil.rmtree(extract_dir)
            os.remove(update_path)
            
            print("✅ Atualização instalada com sucesso!")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao instalar atualização: {e}")
            return False

class UpdateDialog:
    def __init__(self, parent, update_checker):
        self.parent = parent
        self.update_checker = update_checker
        self.dialog = None
        
    def show_update_available(self, update_info):
        """Mostra diálogo de atualização disponível"""
        if not GUI_AVAILABLE:
            return self._console_update_prompt(update_info)
        
        self.dialog = ctk.CTkToplevel(self.parent)
        self.dialog.title("Atualização Disponível")
        self.dialog.geometry("500x400")
        self.dialog.resizable(False, False)
        
        # Centralizar na tela
        self.dialog.transient(self.parent)
        self.dialog.grab_set()
        
        # Frame principal
        main_frame = ctk.CTkFrame(self.dialog)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Título
        title_label = ctk.CTkLabel(
            main_frame,
            text="🔄 Atualização Disponível",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title_label.pack(pady=(20, 10))
        
        # Informações da versão
        version_frame = ctk.CTkFrame(main_frame)
        version_frame.pack(fill="x", padx=20, pady=10)
        
        current_label = ctk.CTkLabel(
            version_frame,
            text=f"Versão Atual: {self.update_checker.current_version}",
            font=ctk.CTkFont(size=14)
        )
        current_label.pack(pady=5)
        
        new_label = ctk.CTkLabel(
            version_frame,
            text=f"Nova Versão: {update_info.get('version', 'N/A')}",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=("#2d5a27", "#90ee90")
        )
        new_label.pack(pady=5)
        
        # Changelog
        changelog_label = ctk.CTkLabel(
            main_frame,
            text="📝 Novidades nesta versão:",
            font=ctk.CTkFont(size=14, weight="bold")
        )
        changelog_label.pack(pady=(20, 5))
        
        changelog_text = ctk.CTkTextbox(main_frame, height=120)
        changelog_text.pack(fill="x", padx=20, pady=5)
        
        changelog_items = update_info.get('changelog', ['Sem informações disponíveis'])
        changelog_content = "\n".join([f"• {item}" for item in changelog_items])
        changelog_text.insert("1.0", changelog_content)
        changelog_text.configure(state="disabled")
        
        # Botões
        button_frame = ctk.CTkFrame(main_frame)
        button_frame.pack(fill="x", padx=20, pady=20)
        
        update_btn = ctk.CTkButton(
            button_frame,
            text="🚀 Atualizar Agora",
            command=self._start_update,
            height=35,
            font=ctk.CTkFont(size=14, weight="bold")
        )
        update_btn.pack(side="left", padx=(0, 10))
        
        later_btn = ctk.CTkButton(
            button_frame,
            text="⏰ Mais Tarde",
            command=self._close_dialog,
            height=35,
            font=ctk.CTkFont(size=14)
        )
        later_btn.pack(side="left")
        
    def _start_update(self):
        """Inicia o processo de atualização"""
        if not self.dialog:
            return
        
        # Desabilitar botões
        for widget in self.dialog.winfo_children():
            if isinstance(widget, ctk.CTkFrame):
                for child in widget.winfo_children():
                    if isinstance(child, ctk.CTkButton):
                        child.configure(state="disabled")
        
        # Mostrar progresso
        progress_label = ctk.CTkLabel(
            self.dialog,
            text="📥 Baixando atualização...",
            font=ctk.CTkFont(size=14)
        )
        progress_label.pack(pady=10)
        
        # Iniciar download em thread separada
        def download_thread():
            try:
                update_path = self.update_checker.download_update()
                if update_path:
                    # Instalar atualização
                    progress_label.configure(text="🔧 Instalando atualização...")
                    if self.update_checker.install_update(update_path):
                        progress_label.configure(text="✅ Atualização concluída!")
                        self.dialog.after(2000, self._restart_app)
                    else:
                        progress_label.configure(text="❌ Erro na instalação")
                else:
                    progress_label.configure(text="❌ Erro no download")
            except Exception as e:
                progress_label.configure(text=f"❌ Erro: {e}")
        
        threading.Thread(target=download_thread, daemon=True).start()
    
    def _restart_app(self):
        """Reinicia o aplicativo"""
        self.dialog.destroy()
        messagebox.showinfo("Reiniciar", "A atualização foi instalada. O aplicativo será reiniciado.")
        
        # Reiniciar aplicativo
        python = sys.executable
        os.execl(python, python, *sys.argv)
    
    def _close_dialog(self):
        """Fecha o diálogo"""
        if self.dialog:
            self.dialog.destroy()
    
    def _console_update_prompt(self, update_info):
        """Prompt de atualização no console (quando GUI não disponível)"""
        print("\n" + "="*60)
        print("🔄 ATUALIZAÇÃO DISPONÍVEL")
        print("="*60)
        print(f"Versão Atual: {self.update_checker.current_version}")
        print(f"Nova Versão: {update_info.get('version', 'N/A')}")
        print("\n📝 Novidades:")
        for item in update_info.get('changelog', []):
            print(f"  • {item}")
        print("\n" + "="*60)
        
        while True:
            choice = input("Deseja atualizar agora? (s/n): ").lower().strip()
            if choice in ['s', 'sim', 'y', 'yes']:
                return self._console_update()
            elif choice in ['n', 'não', 'nao', 'no']:
                print("Atualização cancelada.")
                return False
            else:
                print("Por favor, responda 's' para sim ou 'n' para não.")
    
    def _console_update(self):
        """Atualização via console"""
        try:
            print("📥 Baixando atualização...")
            update_path = self.update_checker.download_update()
            if update_path:
                print("🔧 Instalando atualização...")
                if self.update_checker.install_update(update_path):
                    print("✅ Atualização concluída! Reinicie o aplicativo.")
                    return True
                else:
                    print("❌ Erro na instalação")
            else:
                print("❌ Erro no download")
        except Exception as e:
            print(f"❌ Erro: {e}")
        return False

def check_and_update(parent=None, silent=False):
    """
    Função principal para verificar e atualizar o aplicativo
    parent: janela pai para diálogos (opcional)
    silent: se True, não mostra mensagens de progresso
    """
    try:
        checker = UpdateChecker()
        has_update, update_info, error = checker.check_for_updates(silent)
        
        if error:
            if not silent:
                print(f"❌ Erro ao verificar atualizações: {error}")
            return False
        
        if has_update:
            if GUI_AVAILABLE and parent:
                dialog = UpdateDialog(parent, checker)
                dialog.show_update_available(update_info)
            else:
                # Modo console
                dialog = UpdateDialog(None, checker)
                return dialog._console_update_prompt(update_info)
        else:
            if not silent:
                print("✅ Você está usando a versão mais recente!")
            return False
            
    except Exception as e:
        if not silent:
            print(f"❌ Erro no sistema de atualização: {e}")
        return False

if __name__ == "__main__":
    # Teste do sistema de atualização
    print("🧪 Testando sistema de atualização...")
    check_and_update(silent=False)
