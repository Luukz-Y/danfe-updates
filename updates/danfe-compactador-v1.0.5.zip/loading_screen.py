#!/usr/bin/env python3
"""
Tela de Carregamento - DANFE Compactador
"""

import customtkinter as ctk
import threading
import time
import os
import weakref
from tkinter import messagebox

class LoadingScreen:
    def __init__(self):
        # Configurar CustomTkinter
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        
        # Criar janela de carregamento
        self.loading_window = ctk.CTk()
        self.loading_window.title("DANFE Compactador")
        self.loading_window.geometry("500x300")
        self.loading_window.resizable(False, False)
        self.loading_window.iconbitmap("lc.ico")
        
        # Centralizar janela
        self.center_window()
        
        # Configurar para não mostrar na barra de tarefas
        self.loading_window.attributes('-topmost', True)
        
        # Criar interface
        self.create_loading_interface()
        
        # Variáveis de controle
        self.loading_complete = False
        self.main_app = None
        
        # Configurar limpeza ao fechar
        self.loading_window.protocol("WM_DELETE_WINDOW", self._on_closing)
        
    def center_window(self):
        """Centraliza a janela na tela"""
        self.loading_window.update_idletasks()
        width = self.loading_window.winfo_width()
        height = self.loading_window.winfo_height()
        x = (self.loading_window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.loading_window.winfo_screenheight() // 2) - (height // 2)
        self.loading_window.geometry(f"{width}x{height}+{x}+{y}")
    
    def create_loading_interface(self):
        """Cria a interface da tela de carregamento"""
        # Frame principal
        main_frame = ctk.CTkFrame(self.loading_window, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Logo/Ícone
        logo_label = ctk.CTkLabel(
            main_frame,
            text="📄",
            font=ctk.CTkFont(size=48)
        )
        logo_label.pack(pady=(20, 10))
        
        # Título
        title_label = ctk.CTkLabel(
            main_frame,
            text="DANFE Compactador",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=("#1f538d", "#14375e")
        )
        title_label.pack(pady=(0, 5))
        
        # Subtítulo
        subtitle_label = ctk.CTkLabel(
            main_frame,
            text="Inicializando sistema...",
            font=ctk.CTkFont(size=14),
            text_color=("#666666", "#cccccc")
        )
        subtitle_label.pack(pady=(0, 30))
        
        # Barra de progresso
        self.progress_bar = ctk.CTkProgressBar(
            main_frame,
            width=300,
            height=20,
            corner_radius=10
        )
        self.progress_bar.pack(pady=(0, 20))
        self.progress_bar.set(0)
        
        # Label de status
        self.status_label = ctk.CTkLabel(
            main_frame,
            text="Verificando dependências...",
            font=ctk.CTkFont(size=12),
            text_color=("#666666", "#cccccc")
        )
        self.status_label.pack(pady=(0, 10))
        
        # Versão
        version_label = ctk.CTkLabel(
            main_frame,
            text="v1.0.0",
            font=ctk.CTkFont(size=10),
            text_color=("#999999", "#666666")
        )
        version_label.pack(pady=(20, 0))
    
    def update_status(self, message, progress=None):
        """Atualiza a mensagem de status e progresso"""
        self.status_label.configure(text=message)
        if progress is not None:
            self.progress_bar.set(progress)
        self.loading_window.update()
    
    def start_loading(self, main_app_callback):
        """Inicia o processo de carregamento"""
        def loading_thread():
            try:
                # Simular carregamento com etapas reais
                self.update_status("Verificando dependências...", 0.1)
                time.sleep(0.5)
                
                self.update_status("Carregando bibliotecas...", 0.2)
                time.sleep(0.3)
                
                self.update_status("Inicializando interface...", 0.4)
                time.sleep(0.3)
                
                self.update_status("Verificando atualizações...", 0.6)
                time.sleep(0.5)
                
                self.update_status("Configurando sistema...", 0.8)
                time.sleep(0.3)
                
                self.update_status("Finalizando...", 0.9)
                time.sleep(0.2)
                
                self.update_status("Pronto!", 1.0)
                time.sleep(0.3)
                
                # Fechar tela de carregamento e abrir app principal
                self.loading_complete = True
                try:
                    if self.loading_window.winfo_exists():
                        # Usar after_idle para evitar problemas com after()
                        self.loading_window.after_idle(lambda: self.close_and_open_main(main_app_callback))
                    else:
                        # Fallback: tentar abrir diretamente
                        self.close_and_open_main(main_app_callback)
                except Exception as e:
                    print(f"Erro ao agendar abertura do app principal: {e}")
                    # Fallback: tentar abrir diretamente
                    self.close_and_open_main(main_app_callback)
                
            except Exception as e:
                try:
                    if self.loading_window.winfo_exists():
                        # Usar after_idle para evitar problemas com after()
                        self.loading_window.after_idle(lambda: self.show_error(str(e)))
                    else:
                        # Fallback: mostrar erro diretamente
                        self.show_error(str(e))
                except Exception:
                    # Fallback: mostrar erro diretamente
                    self.show_error(str(e))
        
        # Iniciar thread de carregamento
        threading.Thread(target=loading_thread, daemon=True).start()
    
    def close_and_open_main(self, main_app_callback):
        """Fecha a tela de carregamento e abre o app principal"""
        try:
            self.loading_window.destroy()
            # Criar e executar o app principal
            main_app = main_app_callback()
            main_app.mainloop()
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao iniciar aplicação: {e}")
    
    def show_error(self, error_message):
        """Mostra erro na tela de carregamento"""
        try:
            if hasattr(self, 'status_label') and self.status_label.winfo_exists():
                self.status_label.configure(
                    text=f"Erro: {error_message}",
                    text_color=("#d32f2f", "#ffcdd2")
                )
            
            if hasattr(self, 'loading_window') and self.loading_window.winfo_exists():
                try:
                    # Usar after_idle para evitar problemas com after()
                    self.loading_window.after_idle(lambda: self.loading_window.after(3000, self.loading_window.destroy))
                except Exception:
                    # Fallback: fechar diretamente
                    self.loading_window.destroy()
        except Exception as e:
            print(f"Erro ao mostrar mensagem de erro: {e}")
            # Fallback: fechar janela diretamente
            try:
                if hasattr(self, 'loading_window'):
                    self.loading_window.destroy()
            except:
                pass
    
    def _on_closing(self):
        """Limpa recursos ao fechar a janela de carregamento"""
        try:
            self.loading_window.destroy()
        except Exception as e:
            print(f"Erro ao fechar janela de carregamento: {e}")
    
    def run(self, main_app_callback):
        """Executa a tela de carregamento"""
        self.start_loading(main_app_callback)
        self.loading_window.mainloop()

def show_loading_screen(main_app_callback):
    """Função para mostrar a tela de carregamento"""
    loading = LoadingScreen()
    loading.run(main_app_callback)
